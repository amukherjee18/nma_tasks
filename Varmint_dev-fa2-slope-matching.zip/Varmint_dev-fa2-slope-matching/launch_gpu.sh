salloc -t 04:59:59 --gres=gpu:1 -c 8 --mem=16G srun --pty $SHELL -l

