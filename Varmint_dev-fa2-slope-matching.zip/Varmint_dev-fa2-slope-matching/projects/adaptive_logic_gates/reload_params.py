import os
import sys
import time
import pickle

import varmint

from varmint.physics.constitutive import NeoHookean2D, LinearElastic2D
from varmint.physics.materials import Material
from varmint.solver.incremental_loader import SparseNewtonIncrementalSolver

from varmint.utils.mpi_utils import rprint #, pytree_reduce, test_pytrees_equal
from varmint.utils.train_utils import update_ewa

from adaptive_logic_gates_geometry import construct_cell2D, generate_rectangular_radii
from adaptive_logic_gates_plotting import create_movie_nma, create_static_image_nma

import optax
import haiku as hk

import jax
import jax.numpy as jnp
import numpy as onp

import matplotlib.pyplot as plt

from collections import namedtuple



FLAGS = varmint.flags.FLAGS
varmint.prepare_experiment_args(
    None, exp_root='/home/arinm/Varmint_dev/projects/adaptive_logic_gates/experiments',
            source_root='/home/arinm/Varmint_dev/projects/adaptive_logic_gates')

varmint.config_flags.DEFINE_config_file('config', 'config/default.py')


class TPUMat(Material):
    _E = 0.07
    _nu = 0.30
    _density = 1.25


def main(argv):
    args, dev_id, local_rank = varmint.initialize_experiment(verbose=True)

    config = args.config
    
    comm = namedtuple('comm', ['rank'])
    comm.rank = 0

    rprint(f'Available devices: {jax.devices()}')

    mat = NeoHookean2D(TPUMat)

    # Construct geometry function along with initial radii parameters.
    cell, radii_to_ctrl_fn, n_cells = \
        construct_cell2D(input_str=config.grid_str, patch_ncp=config.ncp,
                         quad_degree=config.quad_deg, spline_degree=config.spline_deg,
                         material=mat)
    init_radii = jnp.concatenate((
            generate_rectangular_radii((n_cells,), config.ncp),
    ))

    # Initialization of local-global transformations, reference control points, tractions.
    potential_energy_fn = cell.get_potential_energy_fn()
    l2g, g2l = cell.get_global_local_maps()
    ref_ctrl = radii_to_ctrl_fn(jnp.array(init_radii))
    tractions = cell.tractions_from_dict({})

    # Set up material parameters based on defaults.
    # We could optimize these per patch if we wanted to.
    mat_params = (
        TPUMat.E * jnp.ones(ref_ctrl.shape[0]),
        TPUMat.nu * jnp.ones(ref_ctrl.shape[0]),
    )

    # Construct optimizer.
    optimizer = SparseNewtonIncrementalSolver(cell, potential_energy_fn, dev_id=dev_id,
                                              **config.solver_parameters)
    optimize = optimizer.get_optimize_fn()

    # Differentiable simulation function for given displacements and radii (decoder).
    def simulate(fixed_disps, control_disps, radii):
        ref_ctrl = radii_to_ctrl_fn(radii)

        # The optimizer works in the global configuration.
        current_x = l2g(ref_ctrl, ref_ctrl)

        # breakpoint()
        increment_dict = config.get_increment_dict(fixed_disps, control_disps)
        current_x, all_xs, all_fixed_locs, solved_increment = \
                optimize(current_x, increment_dict, {}, ref_ctrl, mat_params)

        # Unflatten sequence to local configuration.
        ctrl_seq = cell.unflatten_sequence(
            all_xs, all_fixed_locs, ref_ctrl)
        final_x_local = g2l(current_x, all_fixed_locs[-1], ref_ctrl)

        return final_x_local, [ref_ctrl] + ctrl_seq

    # Initialize neural network (encoder).
    # nn_fn = config.get_nn_fn(
    #         config.max_disp, config.n_layers, config.n_activations, config.n_disps, config.start_point)
    # nn_fn_t = hk.without_apply_rng(hk.transform(nn_fn))
    # init_nn_params = nn_fn_t.init(config.jax_rng, config.start_point)

    # Gather all NMA parameters into a pytree.
    init_control_params = jnp.full(config.num_gates, 0.01)
    curr_all_params = (init_control_params, init_radii)

    target_point = jnp.sum(jnp.abs(radii_to_ctrl_fn(init_radii) - config.target_point), axis=-1) < 1e-14

    def loss_fn(all_params, gate_index):
        control_params, radii = all_params

        set_of_mat_inputs = [jnp.array([1.0, -1.0]), jnp.array([-1.0, 1.0]), jnp.array([1.0, 1.0]), jnp.array([-1.0, -1.0])]

        control_disps = control_params[gate_index]
        # DESIRED LOCATIONS NEEDS TO BE SPECIFIC TO THE CHOSEN GATE SOME_DICT[gate_index]
        desired_locations = config.gate_desired_locs[config.get_gate_from_index(gate_index)]
        desired_locations = config.target_point + desired_locations

        loss = 0

        for i, mat_inputs in enumerate(set_of_mat_inputs):
            # Decoder
            final_x_local, _ = simulate(mat_inputs, control_disps, radii)
            loss += jnp.linalg.norm(final_x_local[target_point][0] - desired_locations[i]) # desired_location will be a function of mat_inputs, stored in some config dictionary    
        return loss

    exp_name = 'exp650891'
    load_iter = 900
    exp_dir = os.path.join(args.exp_root, exp_name)

    rprint('Loading parameters.')
    with open(os.path.join(exp_dir, f'sim-{exp_name}-params-{load_iter}.pkl'), 'rb') as f:
        curr_all_params, all_losses, all_ewa_losses = pickle.load(f)
    rprint('\tDone.')

    rprint(f'Generating image and video with optimization so far.')
    curr_control_params, curr_radii = curr_all_params

    set_of_mat_inputs = [jnp.array([1.0, -1.0]), jnp.array([-1.0, 1.0]), jnp.array([1.0, 1.0]), jnp.array([-1.0, -1.0])]
    gate_names = config.gate_index_dict.keys()
    for i, c in enumerate(curr_control_params):

        # desired_locations = config.gate_desired_locs[gate_names[i]]

        for j, mat_inputs in enumerate(set_of_mat_inputs):
            
            final_x_local, ctrl_seq = simulate(mat_inputs, c, curr_radii)

            image_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-optimized-{gate_names[i]}-{j}.png')
            create_static_image_nma(cell.element, ctrl_seq[-1], image_path, target_point, verbose=True)
            

if __name__ == '__main__':
    varmint.app.run(main)


    
