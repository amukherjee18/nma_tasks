import os
import sys
import time
import pickle

import varmint

from varmint.physics.constitutive import NeoHookean2D, LinearElastic2D
from varmint.physics.materials import Material
from varmint.solver.incremental_loader import SparseNewtonIncrementalSolver

from varmint.utils.mpi_utils import rprint  #, pytree_reduce, test_pytrees_equal
from varmint.utils.train_utils import update_ewa

from adaptive_poisson_geometry import construct_cell2D, generate_bertoldi_radii
# from functapprox_geometry import construct_cell2D, generate_rectangular_radii
from adaptive_poisson_plotting import create_movie_nma, create_static_image_nma

import optax
import haiku as hk

import jax
import jax.numpy as jnp
import numpy as onp

from collections import namedtuple

import matplotlib.pyplot as plt

FLAGS = varmint.flags.FLAGS
varmint.prepare_experiment_args(
    None, exp_root='/home/arinm/Varmint_dev/projects/adaptive_poisson/experiments',
            source_root='/home/arinm/Varmint_dev/projects/adaptive_poisson')

varmint.config_flags.DEFINE_config_file('config', 'config/default.py')


class TPUMat(Material):
    _E = 0.07
    _nu = 0.30
    _density = 1.25

def main(argv):
    args, dev_id, local_rank = varmint.initialize_experiment(verbose=True)
    config = args.config
    comm = namedtuple('comm', ['rank'])
    comm.rank = 0

    rprint(f'Available devices: {jax.devices()}')

    mat = NeoHookean2D(TPUMat)

    # Construct geometry function along with initial radii parameters.        
    cell, radii_to_ctrl_fn, n_cells = \
        construct_cell2D(input_str=config.grid_str, patch_ncp=config.ncp,
                         quad_degree=config.quad_deg, spline_degree=config.spline_deg,
                         material=mat)
    init_radii = jnp.concatenate((
            generate_bertoldi_radii((n_cells,), config.ncp, 0.12, -0.06),
    ))

    # Initialization of local-global transformations, reference control points, tractions.
    potential_energy_fn = cell.get_potential_energy_fn()
    l2g, g2l = cell.get_global_local_maps()
    ref_ctrl = radii_to_ctrl_fn(jnp.array(init_radii))
    tractions = cell.tractions_from_dict({})

    # Set up material parameters based on defaults.
    # We could optimize these per patch if we wanted to.
    mat_params = (
        TPUMat.E * jnp.ones(ref_ctrl.shape[0]),
        TPUMat.nu * jnp.ones(ref_ctrl.shape[0]),
    )

    # Construct optimizer.
    optimizer = SparseNewtonIncrementalSolver(cell, potential_energy_fn, dev_id=dev_id,
                                              **config.solver_parameters)
    optimize = optimizer.get_optimize_fn()

    # Differentiable simulation function for given displacements and radii (decoder).
    def simulate(alpha, disps, radii):
        ref_ctrl = radii_to_ctrl_fn(radii)

        # The optimizer works in the global configuration.
        current_x = l2g(ref_ctrl, ref_ctrl)

        increment_dict = config.get_increment_dict(alpha, disps)

        # breakpoint()
        current_x, all_xs, all_fixed_locs, solved_increment = \
                optimize(current_x, increment_dict, {}, ref_ctrl, mat_params)

        # Unflatten sequence to local configuration.
        ctrl_seq = cell.unflatten_sequence(
            all_xs, all_fixed_locs, ref_ctrl)
        final_x_local = g2l(current_x, all_fixed_locs[-1], ref_ctrl)

        return final_x_local, [ref_ctrl] + ctrl_seq

    # Initialize neural network (encoder).
    nn_fn = config.get_nn_fn(
            config.max_disp, config.n_layers, config.n_activations, config.n_disps, config.start_pr)
    nn_fn_t = hk.without_apply_rng(hk.transform(nn_fn))
    init_nn_params = nn_fn_t.init(config.jax_rng, config.start_pr)

    # Gather all NMA parameters into a pytree.
    curr_all_params = (init_nn_params, init_radii)

    # Target point
    p1 = jnp.sum(jnp.abs(radii_to_ctrl_fn(init_radii) - config.start_point), axis=-1) < 1e-14
    pc = jnp.sum(jnp.abs(radii_to_ctrl_fn(init_radii) - jnp.array([15.0,15.0])), axis=-1) < 1e-14

    def matching_func(m, x):
        return m * x

    start_x = 0
    def plot_loss_fn(all_params, slope, color):
        nn_params, radii = all_params

        # Encoder
        mat_inputs = nn_fn_t.apply(nn_params, slope)
        # breakpoint()

        alphas = onp.arange(-0.5, 0.51, 0.25)

        target_locations = []
        for alpha in alphas:

            # Decoder
            final_x_local, _ = simulate(alpha, mat_inputs, radii)
            target_locations.append(final_x_local[p1][0][0])

            if alpha == 0:
                start_x = final_x_local[p1][0][0]
        
        # plt.plot(alphas, target_locations, color="green", label="Approximation")
        # plt.plot(onp.arange(-0.5, 0.51, 0.01), [config.start_point[0] + matching_func(slope, a) for a in onp.arange(-0.5, 0.51, 0.01)], color="orange", label="Target Function")
        plt.scatter(alphas, onp.array(target_locations) - start_x, marker='x', color=color) # facecolors='none', edgecolors=color)
        plt.plot(onp.arange(-0.5, 0.51, 0.01), [matching_func(slope, a) for a in onp.arange(-0.5, 0.51, 0.01)], color=color, label=f"m = {slope}")

    all_losses = []
    all_ewa_losses = []

    # exp_name = 'exp377652'
    # load_iter = 1000
    # exp_name = 'exp232799'
    # load_iter = 1600
    exp_name = 'exp194294'
    load_iter = 400
    exp_dir = os.path.join(args.exp_root, exp_name)

    # Reload parameters if needed.
    rprint('Loading parameters.')
    with open(os.path.join(exp_dir, f'sim-{exp_name}-params-{load_iter}.pkl'), 'rb') as f:
        curr_all_params, all_losses, all_ewa_losses = pickle.load(f)
    rprint('\tDone.')

    rprint(f'Generating image and video with optimization so far.')
    curr_nn_params, init_radii = curr_all_params

    # test_prs = [-0.8, -0.6, -0.4, -0.2]
    test_prs = [0.2, 0.4, 0.6, 0.8]

    # colors = ['red', 'blue', 'green', 'orange']
    # colors = ['orange', 'green', 'blue', 'red']


     # Append lines to plot for each slope/experiment
    # for i in range(len(test_prs)):
    for test_pr in test_prs:

        mat_inputs = nn_fn_t.apply(curr_nn_params, test_pr)
        _, ctrl_seq = simulate(0.0, mat_inputs, init_radii)

        image_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-optimized-{test_pr}.png')
        create_static_image_nma(cell.element, ctrl_seq[-1], image_path, test_pr, p1=p1, pc=pc, verbose=True)

        # # Find image of final_x_local

        # print(test_prs[i])
        # plot_loss_fn(curr_all_params, test_prs[i], colors[i])

    # plt.legend()
    # plt.title("Adaptive Poisson Ratio Matching ")
    # plt.xlabel("Actuation: Vertical Displacement")
    # plt.ylabel("Target Point: Horizontal Displacement")
    # plt.savefig(os.path.join(args.exp_dir, f'sim-{args.exp_name}-multiline_plot.png'))
    # plt.close()
    print(args.exp_name)


if __name__ == '__main__':
    varmint.app.run(main)