import os
import sys
import time
import pickle

import varmint

from varmint.physics.constitutive import NeoHookean2D, LinearElastic2D
from varmint.physics.materials import Material
from varmint.solver.incremental_loader import SparseNewtonIncrementalSolver

from varmint.utils.mpi_utils import rprint #, pytree_reduce, test_pytrees_equal
from varmint.utils.train_utils import update_ewa

from amplitude_matching_geometry import construct_cell2D, generate_rectangular_radii
from amplitude_matching_plotting import create_movie_nma, create_static_image_nma

import optax
import haiku as hk

import jax
import jax.numpy as jnp
import numpy as onp

import matplotlib.pyplot as plt

from collections import namedtuple



FLAGS = varmint.flags.FLAGS
varmint.prepare_experiment_args(
    None, exp_root='/home/arinm/Varmint_dev/projects/amplitude_matching/experiments',
            source_root='/home/arinm/Varmint_dev/projects/amplitude_matching')

varmint.config_flags.DEFINE_config_file('config', 'config/default.py')


class TPUMat(Material):
    _E = 0.07
    _nu = 0.30
    _density = 1.25


def main(argv):
    args, dev_id, local_rank = varmint.initialize_experiment(verbose=True)

    all_losses = []
    all_ewa_losses = []

    # test_slopes = [2.0, 1.0, 0.6, 0.2]
    exp_names = ['exp374819', 'exp299890', 'exp704517', 'exp568867']
    labels = ['NN + Geometry Optimized', 'Only-NN Optimized', 'Only-NN Optimized (+2 Actuations)', 'Only-NN Optimized (+4 Actuations)']
    colors = ['red', 'blue', 'green', 'orange']
    load_iter = 600
    target_iters = 501
    
    loaded_losses = []
    loaded_ewa_losses = []

    # Save experiment parameters in array
    for i in range(len(exp_names)):
        exp_dir = os.path.join(args.exp_root, exp_names[i])

        rprint(f'Loading parameters from {exp_names[i]}')
        with open(os.path.join(exp_dir, f'sim-{exp_names[i]}-params-{load_iter}.pkl'), 'rb') as f:
            _, all_losses, all_ewa_losses = pickle.load(f)
        rprint('\tDone.')

        loaded_losses.append(all_losses[:target_iters])
        loaded_ewa_losses.append(all_ewa_losses[:target_iters])

    # Export graph of losses
    loss_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-loss.png')
    # plt.title('EWA Training Loss over 500 Iterations')
    plt.title('Training Loss over 500 Iterations')

    # breakpoint()
    for i in range(len(loaded_ewa_losses)):
        plt.plot(loaded_ewa_losses[i], label=labels[i], color=colors[i])

    plt.legend()
    plt.savefig(loss_path)
    plt.close()



if __name__ == '__main__':
    varmint.app.run(main)