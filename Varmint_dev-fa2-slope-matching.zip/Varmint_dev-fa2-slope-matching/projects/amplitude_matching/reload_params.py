import os
import sys
import time
import pickle

import varmint

from varmint.physics.constitutive import NeoHookean2D, LinearElastic2D
from varmint.physics.materials import Material
from varmint.solver.incremental_loader import SparseNewtonIncrementalSolver

from varmint.utils.mpi_utils import rprint #, pytree_reduce, test_pytrees_equal
from varmint.utils.train_utils import update_ewa

from amplitude_matching_geometry import construct_cell2D, generate_rectangular_radii
from amplitude_matching_plotting import create_movie_nma, create_static_image_nma

import optax
import haiku as hk

import jax
import jax.numpy as jnp
import numpy as onp

import matplotlib.pyplot as plt

from collections import namedtuple



FLAGS = varmint.flags.FLAGS
varmint.prepare_experiment_args(
    None, exp_root='/home/arinm/Varmint_dev/projects/amplitude_matching/experiments',
            source_root='/home/arinm/Varmint_dev/projects/amplitude_matching')

varmint.config_flags.DEFINE_config_file('config', 'config/default.py')


class TPUMat(Material):
    _E = 0.07
    _nu = 0.30
    _density = 1.25


def main(argv):
    args, dev_id, local_rank = varmint.initialize_experiment(verbose=True)

    config = args.config
    
    comm = namedtuple('comm', ['rank'])
    comm.rank = 0

    rprint(f'Available devices: {jax.devices()}')

    mat = NeoHookean2D(TPUMat)

    # Construct geometry function along with initial radii parameters.
    cell, radii_to_ctrl_fn, n_cells = \
        construct_cell2D(input_str=config.grid_str, patch_ncp=config.ncp,
                         quad_degree=config.quad_deg, spline_degree=config.spline_deg,
                         material=mat)
    init_radii = jnp.concatenate((
            generate_rectangular_radii((n_cells,), config.ncp),
    ))

    # Initialization of local-global transformations, reference control points, tractions.
    potential_energy_fn = cell.get_potential_energy_fn()
    l2g, g2l = cell.get_global_local_maps()
    ref_ctrl = radii_to_ctrl_fn(jnp.array(init_radii))
    tractions = cell.tractions_from_dict({})

    # Set up material parameters based on defaults.
    # We could optimize these per patch if we wanted to.
    mat_params = (
        TPUMat.E * jnp.ones(ref_ctrl.shape[0]),
        TPUMat.nu * jnp.ones(ref_ctrl.shape[0]),
    )

    # Construct optimizer.
    optimizer = SparseNewtonIncrementalSolver(cell, potential_energy_fn, dev_id=dev_id,
                                              **config.solver_parameters)
    optimize = optimizer.get_optimize_fn()

    # Differentiable simulation function for given displacements and radii (decoder).
    def simulate(disps, radii):
        ref_ctrl = radii_to_ctrl_fn(radii)

        # The optimizer works in the global configuration.
        current_x = l2g(ref_ctrl, ref_ctrl)

        increment_dict = config.get_increment_dict(disps)
        current_x, all_xs, all_fixed_locs, solved_increment = \
                optimize(current_x, increment_dict, {}, ref_ctrl, mat_params)

        # Unflatten sequence to local configuration.
        ctrl_seq = cell.unflatten_sequence(
            all_xs, all_fixed_locs, ref_ctrl)
        final_x_local = g2l(current_x, all_fixed_locs[-1], ref_ctrl)

        return final_x_local, [ref_ctrl] + ctrl_seq

    # Initialize neural network (encoder).
    nn_fn = config.get_nn_fn(
            config.max_disp, config.n_layers, config.n_activations, config.n_disps, config.start_amplitude)
    nn_fn_t = hk.without_apply_rng(hk.transform(nn_fn))
    init_nn_params = nn_fn_t.init(config.jax_rng, config.start_amplitude)

    # Gather all NMA parameters into a pytree.
    curr_all_params = (init_nn_params, init_radii)
    # breakpoint()

    # Determine ctrl points corresponding to top edge
    target_points = []
    resting_positions = onp.array([onp.array([2.5,15]), onp.array([3.75,15]), 
                                    onp.array([5,15]), onp.array([6.25,15]), 
                                    onp.array([7.5,15]), onp.array([8.75,15]), 
                                    onp.array([10,15]), onp.array([11.25,15]), 
                                    onp.array([12.5,15])])

    for p in resting_positions:
        arr = jnp.sum(jnp.abs(radii_to_ctrl_fn(init_radii) - p), axis=-1) < 1e-14

        # Ensures 1 true value for each desired ctrl points.
        first_true_indices = onp.argwhere(arr)
        result_array = onp.full_like(arr, fill_value=False)
        result_array[tuple(first_true_indices[0])] = True
        target_points.append(result_array)

    def target_fn(y0, dx, tA):
        tw = 2*onp.pi/10
        return y0 + tA*onp.sin(tw*(dx))


    # Theta is angle corresponding to desired slope
    def loss_fn(all_params, amplitude):
        nn_params, radii = all_params

        # Encoder
        mat_inputs = nn_fn_t.apply(nn_params, amplitude)

        # Decoder
        final_x_local, _ = simulate(mat_inputs, radii)

        loss = 0
        incr = 1.25

        # Fulcrum on left (adds curvature bias in one direction)
        fulcr_x = final_x_local[target_points[0]][0][0]
        fulcr_y = final_x_local[target_points[0]][0][1]

        # MAKE SURE POINTS ARE IN CORRECT ORDER WHENEVER RUNNING ON NEW TASK
        for i, p in enumerate(target_points):
            if i > 0: # gets rid of norm zero for left most control point on top middle edge
                loss += jnp.linalg.norm(final_x_local[p][0] - jnp.array([fulcr_x + i*incr, target_fn(fulcr_y, i*incr, amplitude)]))
            
        return loss


    # all_losses = []
    # all_ewa_losses = []

    # exp_name = 'exp179921'
    # load_iter = 3200
    exp_name = 'exp374819'
    load_iter = 2000
    exp_dir = os.path.join(args.exp_root, exp_name)


    rprint('Loading parameters.')
    with open(os.path.join(exp_dir, f'sim-{exp_name}-params-{load_iter}.pkl'), 'rb') as f:
        curr_all_params, all_losses, all_ewa_losses = pickle.load(f)
    rprint('\tDone.')

    rprint(f'Generating image and video with optimization so far.')
    curr_nn_params, curr_radii = curr_all_params

    # test_amps = [-0.5, -0.25, 0, 0.25, 0.5]
    test_amps = [-0.5, 0.5]
    # test_amps = [0.5]

    for test_amplitude in test_amps:    

        # Simulate with the test input.
        mat_inputs = nn_fn_t.apply(curr_nn_params, test_amplitude)

        print(f"test amplitude: {test_amplitude}; actuator displacements: {mat_inputs}")

        final_x_local, ctrl_seq = simulate(mat_inputs, curr_radii)

        # Save static image and deformation sequence video.
        exp_dir_curr = os.path.join(args.exp_root, args.exp_name)

        image_path = os.path.join(exp_dir_curr, f'reload-sim-{args.exp_name}-ref_config.png')
        create_static_image_nma(cell.element, ctrl_seq[0], image_path, test_amplitude, target_fn, tp=target_points) #x1, y1, x2, y1 + test_slope * (x2 - x1))

        image_path = os.path.join(exp_dir_curr, f'reload-sim-{exp_name}-optimized-{load_iter}-{test_amplitude}.png')
        create_static_image_nma(cell.element, ctrl_seq[-1], image_path, test_amplitude, target_fn, tp=target_points) #x1, y1, x2, y1 + test_slope * (x2 - x1))

        # vid_path = os.path.join(exp_dir_curr, f'reload-sim-{exp_name}-optimized-{load_iter}-{test_amplitude}.mp4')
        # create_movie_nma(cell.element, ctrl_seq, vid_path, test_amplitude, target_fn, tp=target_points)



if __name__ == '__main__':
    varmint.app.run(main)
