# # For Gamma

# import jax
# import jax.numpy as np
# import numpy as onp
# import matplotlib.pyplot as plt

# from operator import itemgetter
# from matplotlib.animation import FuncAnimation
# import matplotlib.patches as patches

# from varmint.geometry.bsplines import bspline2d
# import varmint.geometry.bsplines as bsplines

# import time

# from varmint.geometry.elements import Element


# def create_movie_nma(
#     element: Element,
#     ctrl_seq,
#     filename,
#     target_params,
#     target_fn,
#     fulcrum_index,
#     fig_kwargs={},
#     comet_exp=None,
#     tp=None,
#     verbose=False,
# ):
#     t0 = time.time()

#     if verbose:
#         print('\tDetermining bounds.')
#     # Get extrema of control points.
#     min_x = np.inf
#     max_x = -np.inf
#     min_y = np.inf
#     max_y = -np.inf
#     for ctrl in ctrl_seq:
#         min_x = float(np.minimum(np.min(ctrl[..., 0]), min_x))
#         max_x = float(np.maximum(np.max(ctrl[..., 0]), max_x))
#         min_y = float(np.minimum(np.min(ctrl[..., 1]), min_y))
#         max_y = float(np.maximum(np.max(ctrl[..., 1]), max_y))

#     # Pad each end by 10%.
#     pad_x = 0.1 * (max_x - min_x)
#     pad_y = 0.1 * (max_y - min_y)
#     min_x -= pad_x
#     max_x += pad_x
#     min_y -= pad_y
#     max_y += pad_y

#     if verbose:
#         print('\tSetting up figure.')
#     # Set up the figure and axes.
#     fig = plt.figure(**fig_kwargs)
#     ax = plt.axes(xlim=(min_x, max_x), ylim=(min_y, max_y))
#     ax.set_aspect('equal')
#     # ax.scatter(target_pts[..., 0], target_pts[..., 1], zorder=10)

#     # Things we need to both initialize and update.
#     objects = {}
#     path = element.get_boundary_path()
#     jit_map_fn = jax.jit(element.get_map_fn(path))

#     def init():
#         # Render the first time step.
#         for i, patch_ctrl in enumerate(ctrl_seq[0]):
#             locs = jit_map_fn(patch_ctrl)
#             # line, = ax.plot(locs[:,0], locs[:,1], 'b-')
#             poly, = ax.fill(locs[:, 0], locs[:, 1],
#                             facecolor='lightsalmon',
#                             edgecolor='orangered',
#                             linewidth=1)
#             objects[(i, 'p')] = poly
#             objects[(i, 'p')].set_visible(False)

#             # initial_point = ctrl_seq[0][p1]
#             # ctrl_seq[0]
#             # point, = ax.plot(initial_point[..., 0], initial_point[..., 1], c='red', zorder=10, marker='o')

#             x1 = ctrl_seq[0][tp[fulcrum_index]][0][0]
#             y1 = ctrl_seq[0][tp[fulcrum_index]][0][1]
#             xs = []
#             target_ys = []

#             x_left = ctrl_seq[0][tp[0]][0][0]
#             x_right = ctrl_seq[0][tp[len(tp)-1]][0][0]
#             num = 20
#             for x in onp.linspace(x_left, x_right, num):
#                 xs.append(x)
#                 target_ys.append(target_fn(y1, x - x1, target_params[0], target_params[1]))
#             # for point in tp:
#             #     xs.append(ctrl_seq[0][point][0][0])
#             #     target_ys.append(target_fn(y1, ctrl_seq[0][point][0][0] - x1, target_distr_param))

#             points, = ax.plot(xs, target_ys, c='red', zorder=10)
#             # ax.scatter(onp.linspace(x1, x2, 25), onp.linspace(y1, y2, 25), c='red', s = 2, zorder=10)

#             objects[(0, 'ip')] = points
#             objects[(0, 'ip')].set_visible(False)

#         return objects.values()

#     def update(tt):
#         for i, patch_ctrl in enumerate(ctrl_seq[tt]):
#             locs = jit_map_fn(patch_ctrl)
#             if tt == 0:
#                 objects[(i, 'p')].set_visible(True)
#             objects[(i, 'p')].set_xy(locs)

#             x1 = ctrl_seq[tt][tp[fulcrum_index]][0][0]
#             y1 = ctrl_seq[tt][tp[fulcrum_index]][0][1]
#             xs = []
#             target_ys = []

#             # breakpoint()
#             x_left = ctrl_seq[tt][tp[0]][0][0]
#             x_right = ctrl_seq[tt][tp[len(tp)-1]][0][0]
#             num = 20
#             for x in onp.linspace(x_left, x_right, num):
#                 xs.append(x)
#                 target_ys.append(target_fn(y1, x - x1, target_params[0], target_params[1]))


#             # for point in tp:
#             #     xs.append(ctrl_seq[tt][point][0][0])
#             #     target_ys.append(target_fn(y1, ctrl_seq[tt][point][0][0] - x1, target_distr_param))

#             objects[(0, 'ip')].set_data(xs, target_ys)
#             # objects[(0, 'ip')].set_offsets(onp.column_stack([onp.linspace(x1, x2, 25), onp.linspace(y1, y2, 25)]))
#             # objects[(0, 'ip')].set_data([initial_point[..., 0]], [initial_point[..., 1]])

#             objects[(0, 'ip')].set_visible(True)

#         return objects.values()

#     if verbose:
#         print('\tAnimating..')
#     anim = FuncAnimation(
#         fig,
#         update,
#         init_func=init,
#         frames=len(ctrl_seq),
#         interval=100,
#         blit=True,
#     )
#     anim.save(filename)

#     if comet_exp is not None:
#         comet_exp.log_figure(figure_name='movie')

#     plt.close(fig)
#     t1 = time.time()
#     if verbose:
#         print(f'Generated movie with {len(ctrl_seq)} frames and '
#               f'{len(ctrl_seq[0])} patches in {t1-t0} seconds.')


# def create_static_image_nma(
#     element: Element,
#     ctrl_sol,
#     filename,
#     target_params,
#     target_fn, 
#     fulcrum_index,
#     tp=None,
#     just_cp=False,
#     fig_kwargs={},
#     verbose=False,
# ):
#     t0 = time.time()

#     # Get extrema of control points.
#     min_x = float(onp.min(ctrl_sol[..., 0]))
#     max_x = float(onp.max(ctrl_sol[..., 0]))

#     min_y = float(onp.min(ctrl_sol[..., 1]))
#     max_y = float(onp.max(ctrl_sol[..., 1]))

#     # Pad each end by 10%.
#     pad_x = 0.1 * (max_x - min_x)
#     pad_y = 0.1 * (max_y - min_y)
#     min_x -= pad_x
#     max_x += pad_x
#     min_y -= pad_y
#     max_y += pad_y

#     # Set up the figure and axes.
#     fig = plt.figure(**fig_kwargs)
#     ax = plt.axes(xlim=(min_x, max_x), ylim=(min_y, max_y))
#     ax.set_aspect('equal')

#     x1 = ctrl_sol[tp[fulcrum_index]][0][0]
#     y1 = ctrl_sol[tp[fulcrum_index]][0][1]
#     xs = []
#     target_ys = []

#     x_left = ctrl_sol[tp[0]][0][0]
#     x_right = ctrl_sol[tp[len(tp)-1]][0][0]
#     num = 20
#     for x in onp.linspace(x_left, x_right, num):
#         xs.append(x)
#         target_ys.append(target_fn(y1, x - x1, target_params[0], target_params[1]))
#     # for point in tp:
#     #     xs.append(ctrl_sol[point][0][0])
#     #     target_ys.append(target_fn(y1, ctrl_sol[point][0][0] - x1, target_distr_param))

#     # ax.scatter(target_pts[..., 0], target_pts[..., 1], zorder=10)
#     ax.plot(xs, target_ys, c = 'blue', zorder = 10)
#     # ax.scatter(onp.linspace(x1, x2, 100), onp.linspace(y1, y2, 100), s = 2, zorder=10)
#     # breakpoint()

#     if just_cp:
#         flat_cp = ctrl_sol.reshape(-1, 2)
#         ax.scatter(flat_cp[:, 0], flat_cp[:, 1], s=10)
#     else:
#         # Things we need to both initialize and update.
#         objects = {}
#         path = element.get_boundary_path()
#         jit_map_fn = jax.jit(element.get_map_fn(path))

#         # Render the first time step.
#         for patch_ctrl in ctrl_sol:
#             locs = jit_map_fn(patch_ctrl)
#             # line, = ax.plot(locs[:,0], locs[:,1], 'b-')
#             poly, = ax.fill(locs[:, 0], locs[:, 1],
#                             facecolor='lightsalmon',
#                             edgecolor='orangered',
#                             linewidth=1)

#     plt.savefig(filename)

#     plt.close(fig)
#     t1 = time.time()
#     if verbose:
#         print(f'Generated image with {len(ctrl_sol)} patches in {t1-t0} seconds.')


import jax
import jax.numpy as np
import numpy as onp
import matplotlib.pyplot as plt

from operator import itemgetter
from matplotlib.animation import FuncAnimation
import matplotlib.patches as patches

from varmint.geometry.bsplines import bspline2d
import varmint.geometry.bsplines as bsplines

import time

from varmint.geometry.elements import Element


def create_movie_nma(
    element: Element,
    ctrl_seq,
    filename,
    target_distr_param,
    target_fn,
    fulcrum_index,
    fig_kwargs={},
    comet_exp=None,
    tp=None,
    verbose=False,
):
    t0 = time.time()

    if verbose:
        print('\tDetermining bounds.')
    # Get extrema of control points.
    min_x = np.inf
    max_x = -np.inf
    min_y = np.inf
    max_y = -np.inf
    for ctrl in ctrl_seq:
        min_x = float(np.minimum(np.min(ctrl[..., 0]), min_x))
        max_x = float(np.maximum(np.max(ctrl[..., 0]), max_x))
        min_y = float(np.minimum(np.min(ctrl[..., 1]), min_y))
        max_y = float(np.maximum(np.max(ctrl[..., 1]), max_y))

    # Pad each end by 10%.
    pad_x = 0.1 * (max_x - min_x)
    pad_y = 0.1 * (max_y - min_y)
    min_x -= pad_x
    max_x += pad_x
    min_y -= pad_y
    max_y += pad_y

    if verbose:
        print('\tSetting up figure.')
    # Set up the figure and axes.
    fig = plt.figure(**fig_kwargs)
    ax = plt.axes(xlim=(min_x, max_x), ylim=(min_y, max_y))
    ax.set_aspect('equal')
    # ax.scatter(target_pts[..., 0], target_pts[..., 1], zorder=10)

    # Things we need to both initialize and update.
    objects = {}
    path = element.get_boundary_path()
    jit_map_fn = jax.jit(element.get_map_fn(path))

    def init():
        # Render the first time step.
        for i, patch_ctrl in enumerate(ctrl_seq[0]):
            locs = jit_map_fn(patch_ctrl)
            # line, = ax.plot(locs[:,0], locs[:,1], 'b-')
            poly, = ax.fill(locs[:, 0], locs[:, 1],
                            facecolor='lightsalmon',
                            edgecolor='orangered',
                            linewidth=1)
            objects[(i, 'p')] = poly
            objects[(i, 'p')].set_visible(False)

            # initial_point = ctrl_seq[0][p1]
            # ctrl_seq[0]
            # point, = ax.plot(initial_point[..., 0], initial_point[..., 1], c='red', zorder=10, marker='o')

            x1 = ctrl_seq[0][tp[fulcrum_index]][0][0]
            y1 = ctrl_seq[0][tp[fulcrum_index]][0][1]
            xs = []
            target_ys = []

            x_left = ctrl_seq[0][tp[0]][0][0]
            x_right = ctrl_seq[0][tp[len(tp)-1]][0][0]
            num = 20
            for x in onp.linspace(x_left, x_right, num):
                xs.append(x)
                target_ys.append(target_fn(y1, x - x1, target_distr_param))
            # for point in tp:
            #     xs.append(ctrl_seq[0][point][0][0])
            #     target_ys.append(target_fn(y1, ctrl_seq[0][point][0][0] - x1, target_distr_param))

            points, = ax.plot(xs, target_ys, c='red', zorder=10)
            # ax.scatter(onp.linspace(x1, x2, 25), onp.linspace(y1, y2, 25), c='red', s = 2, zorder=10)

            objects[(0, 'ip')] = points
            objects[(0, 'ip')].set_visible(False)

        return objects.values()

    def update(tt):
        for i, patch_ctrl in enumerate(ctrl_seq[tt]):
            locs = jit_map_fn(patch_ctrl)
            if tt == 0:
                objects[(i, 'p')].set_visible(True)
            objects[(i, 'p')].set_xy(locs)

            x1 = ctrl_seq[tt][tp[fulcrum_index]][0][0]
            y1 = ctrl_seq[tt][tp[fulcrum_index]][0][1]
            xs = []
            target_ys = []

            # breakpoint()
            x_left = ctrl_seq[tt][tp[0]][0][0]
            x_right = ctrl_seq[tt][tp[len(tp)-1]][0][0]
            num = 20
            for x in onp.linspace(x_left, x_right, num):
                xs.append(x)
                target_ys.append(target_fn(y1, x - x1, target_distr_param))


            # for point in tp:
            #     xs.append(ctrl_seq[tt][point][0][0])
            #     target_ys.append(target_fn(y1, ctrl_seq[tt][point][0][0] - x1, target_distr_param))

            objects[(0, 'ip')].set_data(xs, target_ys)
            # objects[(0, 'ip')].set_offsets(onp.column_stack([onp.linspace(x1, x2, 25), onp.linspace(y1, y2, 25)]))
            # objects[(0, 'ip')].set_data([initial_point[..., 0]], [initial_point[..., 1]])

            objects[(0, 'ip')].set_visible(True)

        return objects.values()

    if verbose:
        print('\tAnimating..')
    anim = FuncAnimation(
        fig,
        update,
        init_func=init,
        frames=len(ctrl_seq),
        interval=100,
        blit=True,
    )
    anim.save(filename)

    if comet_exp is not None:
        comet_exp.log_figure(figure_name='movie')

    plt.close(fig)
    t1 = time.time()
    if verbose:
        print(f'Generated movie with {len(ctrl_seq)} frames and '
              f'{len(ctrl_seq[0])} patches in {t1-t0} seconds.')


def create_static_image_nma(
    element: Element,
    ctrl_sol,
    filename,
    target_distr_param,
    target_fn, 
    fulcrum_index,
    tp=None,
    just_cp=False,
    fig_kwargs={},
    verbose=False,
):
    t0 = time.time()

    # Get extrema of control points.
    min_x = float(onp.min(ctrl_sol[..., 0]))
    max_x = float(onp.max(ctrl_sol[..., 0]))

    min_y = float(onp.min(ctrl_sol[..., 1]))
    max_y = float(onp.max(ctrl_sol[..., 1]))

    # Pad each end by 10%.
    pad_x = 0.1 * (max_x - min_x)
    pad_y = 0.1 * (max_y - min_y)
    min_x -= pad_x
    max_x += pad_x
    min_y -= pad_y
    max_y += pad_y

    # Set up the figure and axes.
    fig = plt.figure(**fig_kwargs)
    ax = plt.axes(xlim=(min_x, max_x), ylim=(min_y, max_y))
    ax.set_aspect('equal')

    x1 = ctrl_sol[tp[0]][0][0]
    y1 = ctrl_sol[tp[0]][0][1]

    x2 = ctrl_sol[tp[len(tp) - 1]][0][0]
    y2 = ctrl_sol[tp[len(tp) - 1]][0][1]

    ax.plot([x1, x2], [y1, y2], c = 'red', linewidth=2, zorder = 20)


    xs = []
    target_ys = []

    x_left = ctrl_sol[tp[0]][0][0]
    x_right = ctrl_sol[tp[len(tp)-1]][0][0]
    num = 20
    for x in onp.linspace(x_left, x_right, num):
        xs.append(x)
        target_ys.append(target_fn(y1, x - x1, target_distr_param))
    # for point in tp:
    #     xs.append(ctrl_sol[point][0][0])
    #     target_ys.append(target_fn(y1, ctrl_sol[point][0][0] - x1, target_distr_param))

    # ax.scatter(target_pts[..., 0], target_pts[..., 1], zorder=10)
    # ax.plot(xs, target_ys, c = 'red', linewidth=2, zorder = 10)
    ax.scatter([0, 0, 15, 15], [0, 15, 0, 15], c = 'black', zorder = 10)

    # ax.scatter(onp.linspace(x1, x2, 100), onp.linspace(y1, y2, 100), s = 2, zorder=10)
    # breakpoint()

    if just_cp:
        flat_cp = ctrl_sol.reshape(-1, 2)
        ax.scatter(flat_cp[:, 0], flat_cp[:, 1], s=10)
    else:
        # Things we need to both initialize and update.
        objects = {}
        path = element.get_boundary_path()
        jit_map_fn = jax.jit(element.get_map_fn(path))

        # Render the first time step.
        for patch_ctrl in ctrl_sol:
            locs = jit_map_fn(patch_ctrl)
            # line, = ax.plot(locs[:,0], locs[:,1], 'b-')
            poly, = ax.fill(locs[:, 0], locs[:, 1],
                            facecolor='lightsalmon',
                            edgecolor='orangered',
                            linewidth=1)

    plt.savefig(filename)

    plt.close(fig)
    t1 = time.time()
    if verbose:
        print(f'Generated image with {len(ctrl_sol)} patches in {t1-t0} seconds.')
