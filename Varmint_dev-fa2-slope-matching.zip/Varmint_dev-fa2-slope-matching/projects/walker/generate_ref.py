import os
import sys
import time
import pickle

import varmint

from varmint.physics.constitutive import NeoHookean2D, LinearElastic2D
from varmint.physics.materials import Material
from varmint.solver.incremental_loader import SparseNewtonIncrementalSolver

from varmint.utils.mpi_utils import rprint  #, pytree_reduce, test_pytrees_equal
from varmint.utils.train_utils import update_ewa

from geometry.walker_geometry import construct_cell2D, generate_bertoldi_radii, generate_rectangular_radii
# from functapprox_geometry import construct_cell2D, generate_rectangular_radii
from functapprox_plotting import create_movie_nma, create_static_image_nma

import optax
import haiku as hk

import jax
import jax.numpy as jnp
import numpy as onp

from collections import namedtuple

import matplotlib.pyplot as plt

FLAGS = varmint.flags.FLAGS
varmint.prepare_experiment_args(
    None, exp_root='/home/arinm/Varmint_dev/projects/walker/experiments',
            source_root='/home/arinm/Varmint_dev/projects/walker')

varmint.config_flags.DEFINE_config_file('config', 'config/default.py')


class TPUMat(Material):
    _E = 0.07
    _nu = 0.30
    _density = 1.25

def main(argv):
    args, dev_id, local_rank = varmint.initialize_experiment(verbose=True)
    config = args.config
    comm = namedtuple('comm', ['rank'])
    comm.rank = 0

    rprint(f'Available devices: {jax.devices()}')

    mat = NeoHookean2D(TPUMat)

    # Construct geometry function along with initial radii parameters.        
    cell, radii_to_ctrl_fn, n_cells = \
        construct_cell2D(input_str=config.grid_str, patch_ncp=config.ncp,
                         quad_degree=config.quad_deg, spline_degree=config.spline_deg,
                         material=mat)
    # init_radii = jnp.concatenate((
    #         generate_bertoldi_radii((n_cells,), config.ncp, 0.12, -0.06),
    # ))
    init_radii = jnp.concatenate((
            generate_rectangular_radii((n_cells,), config.ncp),
    ))
    

    # Initialization of local-global transformations, reference control points, tractions.
    potential_energy_fn = cell.get_potential_energy_fn()
    l2g, g2l = cell.get_global_local_maps()
    ref_ctrl = radii_to_ctrl_fn(jnp.array(init_radii))
    tractions = cell.tractions_from_dict({})

    # Set up material parameters based on defaults.
    # We could optimize these per patch if we wanted to.
    mat_params = (
        TPUMat.E * jnp.ones(ref_ctrl.shape[0]),
        TPUMat.nu * jnp.ones(ref_ctrl.shape[0]),
    )

    # Construct optimizer.
    optimizer = SparseNewtonIncrementalSolver(cell, potential_energy_fn, dev_id=dev_id,
                                              **config.solver_parameters)
    optimize = optimizer.get_optimize_fn()

    # Differentiable simulation function for given displacements and radii (decoder).
    def simulate(alpha, radii):
        ref_ctrl = radii_to_ctrl_fn(radii)

        # The optimizer works in the global configuration.
        current_x = l2g(ref_ctrl, ref_ctrl)

        increment_dict = config.get_increment_dict(alpha)

        current_x, all_xs, all_fixed_locs, solved_increment = \
                optimize(current_x, increment_dict, {}, ref_ctrl, mat_params)

        # Unflatten sequence to local configuration.
        ctrl_seq = cell.unflatten_sequence(
            all_xs, all_fixed_locs, ref_ctrl)
        final_x_local = g2l(current_x, all_fixed_locs[-1], ref_ctrl)

        return final_x_local, [ref_ctrl] + ctrl_seq

    # Initialize neural network (encoder).
    nn_fn = config.get_nn_fn(
            config.max_disp, config.n_layers, config.n_activations, config.n_disps, config.start_point)
    nn_fn_t = hk.without_apply_rng(hk.transform(nn_fn))
    init_nn_params = nn_fn_t.init(config.jax_rng, config.start_point)

    # Gather all NMA parameters into a pytree.
    curr_all_params = (init_nn_params, init_radii)

    # Target point
    p1 = jnp.sum(jnp.abs(radii_to_ctrl_fn(init_radii) - config.start_point), axis=-1) < 1e-14

    # def matching_func(x):
    #     return 1 - onp.exp(x)

    def matching_func(x):
        return -0.25*x

    def loss_fn(all_params, target):
        nn_params, radii = all_params
        alphas = onp.arange(-0.5, 0.51, 0.25)

        # Decoder
        loss_sum = 0
        for alpha in alphas:
            final_x_local, _ = simulate(alpha, radii)

            # We want our identified point (p1) at a specified location (target).
            loss_sum += jnp.abs(final_x_local[p1][0][0] - (target + matching_func(alpha))) / ref_ctrl[p1].shape[0]
    
        return loss_sum

    def plot_loss_fn(all_params, target, plot_path):
        nn_params, radii = all_params

        alphas = onp.arange(-0.5, 0.51, 0.10)

        # Decoder
        target_locations = jnp.array([])

        for alpha in alphas:
            final_x_local, _ = simulate(alpha, radii)
            target_locations = jnp.append(target_locations, final_x_local[p1][0][0] - target)
            
        plt.plot(alphas, target_locations, color="blue")
        plt.title("Deformation of Unoptimized Geometry")
        plt.xlabel("Actuation: Vertical Displacement")
        plt.ylabel("Target Point: Horizontal Displacement")
        # plt.plot(onp.arange(-0.5, 0.51, 0.01), [matching_func(a) for a in onp.arange(-0.5, 0.51, 0.01)], color="blue", linestyle='dashed', label="Target Function")
        # plt.legend()
        plt.savefig(plot_path)

    test_disps = config.start_point

    plot_loss_fn(curr_all_params, test_disps[comm.rank], os.path.join(args.exp_dir, f'sim-{args.exp_name}-targetpoint.png'))


    alpha = 2

    # Simulate 
    _, ctrl_seq = simulate(alpha, init_radii)

    # Save static image and deformation sequence video.
    image_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-ref_config-preopt.png')
    print(image_path)
    create_static_image_nma(cell.element, ctrl_seq[0], image_path, test_disps, verbose=True)

    vid_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-preoptimized-{alpha}.mp4')
    create_movie_nma(cell.element, ctrl_seq, vid_path, test_disps, p1=p1, verbose=True)

if __name__ == '__main__':
    varmint.app.run(main)
