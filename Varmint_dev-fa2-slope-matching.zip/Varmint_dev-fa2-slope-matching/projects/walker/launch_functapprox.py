import os
import sys
import time
import pickle

import varmint

from varmint.physics.constitutive import NeoHookean2D, LinearElastic2D
from varmint.physics.materials import Material
from varmint.solver.incremental_loader import SparseNewtonIncrementalSolver

from varmint.utils.mpi_utils import rprint  #, pytree_reduce, test_pytrees_equal
from varmint.utils.train_utils import update_ewa

from geometry.walker_geometry import construct_cell2D, generate_bertoldi_radii
# from functapprox_geometry import construct_cell2D, generate_rectangular_radii
from functapprox_plotting import create_movie_nma, create_static_image_nma

import optax
import haiku as hk

import jax
import jax.numpy as jnp
import numpy as onp

from collections import namedtuple

import matplotlib.pyplot as plt

FLAGS = varmint.flags.FLAGS
varmint.prepare_experiment_args(
    None, exp_root='/home/arinm/Varmint_dev/projects/walker/experiments',
            source_root='/home/arinm/Varmint_dev/projects/walker')

varmint.config_flags.DEFINE_config_file('config', 'config/default.py')


class TPUMat(Material):
    _E = 0.07
    _nu = 0.30
    _density = 1.25

def main(argv):
    args, dev_id, local_rank = varmint.initialize_experiment(verbose=True)
    config = args.config
    comm = namedtuple('comm', ['rank'])
    comm.rank = 0

    rprint(f'Available devices: {jax.devices()}')

    mat = NeoHookean2D(TPUMat)

    # Construct geometry function along with initial radii parameters.        
    cell, radii_to_ctrl_fn, n_cells = \
        construct_cell2D(input_str=config.grid_str, patch_ncp=config.ncp,
                         quad_degree=config.quad_deg, spline_degree=config.spline_deg,
                         material=mat)
    init_radii = jnp.concatenate((
            generate_bertoldi_radii((n_cells,), config.ncp, 0.12, -0.06),
    ))

    # Initialization of local-global transformations, reference control points, tractions.
    potential_energy_fn = cell.get_potential_energy_fn()
    l2g, g2l = cell.get_global_local_maps()
    ref_ctrl = radii_to_ctrl_fn(jnp.array(init_radii))
    tractions = cell.tractions_from_dict({})

    # Set up material parameters based on defaults.
    # We could optimize these per patch if we wanted to.
    mat_params = (
        TPUMat.E * jnp.ones(ref_ctrl.shape[0]),
        TPUMat.nu * jnp.ones(ref_ctrl.shape[0]),
    )

    # Construct optimizer.
    optimizer = SparseNewtonIncrementalSolver(cell, potential_energy_fn, dev_id=dev_id,
                                              **config.solver_parameters)
    optimize = optimizer.get_optimize_fn()

    # Differentiable simulation function for given displacements and radii (decoder).
    def simulate(alpha, radii):
        ref_ctrl = radii_to_ctrl_fn(radii)

        # The optimizer works in the global configuration.
        current_x = l2g(ref_ctrl, ref_ctrl)

        increment_dict = config.get_increment_dict(alpha)

        current_x, all_xs, all_fixed_locs, solved_increment = \
                optimize(current_x, increment_dict, {}, ref_ctrl, mat_params)

        # Unflatten sequence to local configuration.
        ctrl_seq = cell.unflatten_sequence(
            all_xs, all_fixed_locs, ref_ctrl)
        final_x_local = g2l(current_x, all_fixed_locs[-1], ref_ctrl)

        return final_x_local, [ref_ctrl] + ctrl_seq

    # Gather all NMA parameters into a pytree.
    curr_all_params = init_radii

    # Target point
    p1 = jnp.sum(jnp.abs(radii_to_ctrl_fn(init_radii) - config.start_point), axis=-1) < 1e-14

    def matching_func(m, x):
        return m * x

    def loss_fn(all_params, slope):
        radii = all_params

        alphas = onp.arange(-0.5, 0.51, 0.25)

        loss_sum = 0
        for alpha in alphas:
            final_x_local, _ = simulate(alpha, radii)
            loss_sum += jnp.abs(final_x_local[p1][0][0] - (config.start_point[0] + matching_func(slope, alpha))) / ref_ctrl[p1].shape[0]
    
        return loss_sum

    def plot_loss_fn(all_params, slope, plot_path):
        radii = all_params

        alphas = onp.arange(-0.5, 0.51, 0.10)

        target_locations = jnp.array([])
        for alpha in alphas:

            # Decoder
            final_x_local, _ = simulate(alpha, radii)
            target_locations = jnp.append(target_locations, final_x_local[p1][0][0])
            
        plt.plot(alphas, target_locations, color="green", label="Approximation")
        plt.plot(onp.arange(-0.5, 0.51, 0.01), [config.start_point[0] + matching_func(slope, a) for a in onp.arange(-0.5, 0.51, 0.01)], color="orange", label="Target Function")
        plt.legend()
        plt.savefig(plot_path)
        plt.close()

    def plot_loss_curve(losses, ewa_losses, loss_path):
        plt.title('Loss over iterations')
        plt.plot(losses, label='loss')
        plt.plot(ewa_losses, label='EWA loss')
        plt.legend()
        print(loss_path)
        plt.savefig(loss_path)
        plt.close()

    all_losses = []
    all_ewa_losses = []

    # Reload parameters if needed.
    if args.reload:
        rprint('Loading parameters.')
        with open(os.path.join(args.exp_dir, f'sim-{args.exp_name}-params-{args.load_iter}.pkl'), 'rb') as f:
            curr_all_params, all_losses, all_ewa_losses = pickle.load(f)
        rprint('\tDone.')

    # Scale the lr depending on the batch size.
    batch_size = 1
    lr = config.lr * batch_size

    optimizer = optax.adam(lr)
    opt_state = optimizer.init(curr_all_params)

    loss_val_and_grad = jax.value_and_grad(loss_fn)
    ewa_loss = None

    avg_losses = []
    ewa_losses = []

    rprint(f'All processes at barrier. Starting training over {batch_size} MPI ranks.')
    for i in range(args.load_iter + 1, config.max_iter):
        iter_time = time.time()

        slope = config.slope # Defines matching_function

        loss, grad_loss = loss_val_and_grad(curr_all_params, slope)
        avg_loss = loss 
        avg_grad_loss = grad_loss
        ewa_loss = update_ewa(ewa_loss, avg_loss, config.ewa_weight)

        avg_losses.append(avg_loss)
        ewa_losses.append(ewa_loss)

        if i % config.eval_every == 0:
            plot_loss_fn(curr_all_params, slope, os.path.join(args.exp_dir, f'sim-{args.exp_name}-targetpoint.png'))

        with open('losses.txt', 'w') as file:
            for al in avg_losses:
                file.write(str(al) + ", ")
            file.write("\n")
            for el in ewa_losses:
                file.write(str(el) + ", ")

        rprint(f'{args.exp_name} - Iteration {i} Loss: {avg_loss} EWA Loss: {ewa_loss} Time: {time.time() - iter_time}')

        all_losses.append(avg_loss)
        all_ewa_losses.append(ewa_loss)

        # Update geometry based on loss
        updates, opt_state = optimizer.update(avg_grad_loss, opt_state)
        curr_all_params = optax.apply_updates(curr_all_params, updates)

        # Clip radii
        curr_radii = curr_all_params
        curr_radii = jnp.clip(curr_radii, *config.radii_range)
        curr_all_params = curr_radii

        if i % config.eval_every == 0:

            # Generate video
            if comm.rank == 0:
                rprint(f'Generating image and video with optimization so far.')
                curr_radii = curr_all_params

                slope = config.slope

                # Alpha is the actuation that we specify for this task (since we are not using the encoder)
                alpha = 2
                alpha2 = -2

                # Simulate 
                _, ctrl_seq = simulate(alpha, curr_radii)
                _, ctrl_seq2 = simulate(alpha2, curr_radii)

                # Save static image and deformation sequence video.
                image_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-ref_config-{i}.png')
                create_static_image_nma(cell.element, ctrl_seq[0], image_path, slope, p1=p1, verbose=True)

                # image_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-optimized-{i}.png')
                # create_static_image_nma(cell.element, ctrl_seq[-1], image_path, test_disps, verbose=True)

                # vid_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-optimized-{i}.mp4')
                # create_movie_nma(cell.element, ctrl_seq, vid_path, test_disps, p1=p1, verbose=True)

                # vid_path2 = os.path.join(args.exp_dir, f'sim-{args.exp_name}-optimized2-{i}.mp4')
                # create_movie_nma(cell.element, ctrl_seq2, vid_path2, test_disps, p1=p1, verbose=True)

                # Export graph of losses
                loss_path = os.path.join(args.exp_dir, f'sim-{args.exp_name}-loss.png')
                plot_loss_curve(all_losses, all_ewa_losses, loss_path)


        if i % config.save_every == 0:
            # Pickle parameters
            if comm.rank == 0:
                rprint('Saving parameters.')
                with open(os.path.join(args.exp_dir, f'sim-{args.exp_name}-params-{i}.pkl'), 'wb') as f:
                    pickle.dump((curr_all_params, all_losses, all_ewa_losses), f)
                rprint('\tDone.')


if __name__ == '__main__':
    varmint.app.run(main)