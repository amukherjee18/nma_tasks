import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Create a figure and an axis
fig, ax = plt.subplots()

# Set the axis limits
ax.set_xlim(-5, 5)
ax.set_ylim(-5, 5)

# Create a blue dot (circle) representing the moving point
dot, = ax.plot([], [], 'bo', markersize=10)

# Function to initialize the animation
def init():
    dot.set_data([], [])
    return dot,

# Function to update the animation frame
def update(frame):
    x = frame / 10  # Adjust the speed and distance of the animation
    y = x  # y = x for the line
    dot.set_data(x, y)
    return dot,

# Create the animation
ani = FuncAnimation(fig, update, frames=range(-50, 51), init_func=init, repeat=True, blit=True)

plt.show()
