import os
import time
import collections

import jax
import numpy as np

#from mpi4py import MPI
from absl import logging


def rprint(*args, comm=None, **kwargs):
    print(*args, flush=True, **kwargs)

